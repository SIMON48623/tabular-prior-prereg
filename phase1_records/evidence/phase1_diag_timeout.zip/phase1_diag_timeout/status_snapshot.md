# Phase 1 status snapshot

- Snapshot time UTC: 2026-09-29T01:28:39.848289+00:00
- Source runtime root on each host: `/root/autodl-tmp/phase1_run_b7ba9544/runtime`

| host | scheduler_pid | scheduler_alive | workers | M1 completed checkpoint JSON files | scheduler failure events | failed units | fatal_attempt files copied |
|---|---:|---|---:|---:|---:|---:|---:|
| 686 | 36390 | true | 32 | 1063 | 25 | 10 | 15 |
| 214 | 19898 | true | 32 | 1171 | 34 | 15 | 19 |
| 4090 | 1863 | true | 1 | 2618 | 0 | 0 | 0 |

## Failed units recorded in completed M1 checkpoints

### 686

- `M1|44709|raw|0|cpu` — unit exceeded 7572.837196 seconds
- `M1|44709|raw|1|cpu` — unit exceeded 7572.837196 seconds
- `M1|44709|raw|2|cpu` — unit exceeded 7572.837196 seconds
- `M1|44709|raw|3|cpu` — unit exceeded 7572.837196 seconds
- `M1|44709|raw|4|cpu` — unit exceeded 7572.837196 seconds
- `M1|44711|raw|0|cpu` — unit exceeded 7572.837196 seconds
- `M1|44711|raw|1|cpu` — unit exceeded 7572.837196 seconds
- `M1|44711|raw|2|cpu` — unit exceeded 7572.837196 seconds
- `M1|44711|raw|3|cpu` — unit exceeded 7572.837196 seconds
- `M1|44711|raw|4|cpu` — unit exceeded 7572.837196 seconds

### 214

- `M1|44708|raw|0|cpu` — unit exceeded 7572.837196 seconds
- `M1|44708|raw|1|cpu` — unit exceeded 7572.837196 seconds
- `M1|44708|raw|2|cpu` — unit exceeded 7572.837196 seconds
- `M1|44708|raw|3|cpu` — unit exceeded 7572.837196 seconds
- `M1|44708|raw|4|cpu` — unit exceeded 7572.837196 seconds
- `M1|44710|raw|0|cpu` — unit exceeded 7572.837196 seconds
- `M1|44710|raw|1|cpu` — unit exceeded 7572.837196 seconds
- `M1|44710|raw|2|cpu` — unit exceeded 7572.837196 seconds
- `M1|44710|raw|3|cpu` — unit exceeded 7572.837196 seconds
- `M1|44710|raw|4|cpu` — unit exceeded 7572.837196 seconds
- `M1|44712|raw|0|cpu` — unit exceeded 7572.837196 seconds
- `M1|44712|raw|1|cpu` — unit exceeded 7572.837196 seconds
- `M1|44712|raw|2|cpu` — unit exceeded 7572.837196 seconds
- `M1|44712|raw|3|cpu` — unit exceeded 7572.837196 seconds
- `M1|44712|raw|4|cpu` — unit exceeded 7572.837196 seconds

### 4090

- None recorded.

## Runtime-source presence

- 686: `scheduler_failures.jsonl` present; `fatal_attempts/` present.
- 214: `scheduler_failures.jsonl` present; `fatal_attempts/` present.
- 4090: `scheduler_failures.jsonl` absent; `fatal_attempts/` absent.
