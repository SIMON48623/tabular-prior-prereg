"""Temporary, read-only Phase 1 timing controller for the 214 host."""

from __future__ import annotations

import csv
import json
import multiprocessing as mp
import os
import resource
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

RUN_ROOT = Path('/root/autodl-tmp/phase1_run_b7ba9544')
REGISTERED_ROOT = Path('/root/autodl-tmp/tabular_prior_phase1_setup/tabular_prior_v2')
OUTPUT = Path('/root/phase1_diag_timeout')
SCHEDULER_PID_FILE = RUN_ROOT / 'scheduler.pid'
MODELS = ('lr', 'ebm', 'catboost', 'lgbm', 'xgb', 'rf')
TIME_LIMIT_SECONDS = 10800.0
FIELDS = (
    'variant', 'model', 'n_train', 'n_test', 'p', 'n_categorical',
    'seconds', 'peak_rss_mb', 'status', 'error',
)


def timestamp() -> str:
    return datetime.now(timezone.utc).isoformat()


def worker_count(scheduler_pid: int) -> int:
    output = subprocess.check_output(
        ['ps', '--ppid', str(scheduler_pid), '-o', 'args='], text=True,
    )
    return sum('spawn_main' in line for line in output.splitlines())


def context_snapshot() -> dict[str, object]:
    scheduler_pid = int(SCHEDULER_PID_FILE.read_text().strip())
    return {
        'time_utc': timestamp(),
        'uptime': subprocess.check_output(['uptime'], text=True).strip(),
        'uptime_seconds': float(Path('/proc/uptime').read_text().split()[0]),
        'scheduler_pid': scheduler_pid,
        'scheduler_worker_count': worker_count(scheduler_pid),
    }


def write_json(path: Path, value: object) -> None:
    temporary = path.with_name(path.name + f'.{os.getpid()}.tmp')
    with temporary.open('w', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, sort_keys=True, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def write_timing(rows: list[dict[str, object]]) -> None:
    path = OUTPUT / 'timing_44708.csv'
    temporary = path.with_name(path.name + f'.{os.getpid()}.tmp')
    with temporary.open('w', encoding='utf-8', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(rows)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def current_rss_mb(pid: int) -> float | None:
    try:
        content = Path(f'/proc/{pid}/status').read_text()
    except (FileNotFoundError, ProcessLookupError):
        return None
    for line in content.splitlines():
        if line.startswith('VmHWM:'):
            return float(line.split()[1]) / 1024.0
    return None


def child_fit(
    connection: object,
    model: str,
    train: object,
    labels: object,
    test: object,
    categorical: list[str],
) -> None:
    from phase1_driver.execution import cpu_fit_predict, seed_cpu_process
    from phase1_driver.runtime import offline_socket_guard, set_offline_environment
    import numpy as np

    try:
        seed_cpu_process()
        set_offline_environment()
        started = time.perf_counter()
        with offline_socket_guard():
            prediction, _detail = cpu_fit_predict(
                model, train, labels, test, categorical, REGISTERED_ROOT,
            )
        seconds = time.perf_counter() - started
        vector = np.asarray(prediction)
        if vector.shape != (len(test),):
            raise RuntimeError(f'prediction length {vector.shape}, expected {(len(test),)}')
        if not np.isfinite(vector).all():
            raise RuntimeError('prediction contains non-finite values')
        connection.send({
            'seconds': seconds,
            'peak_rss_mb': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024.0,
            'status': 'ok',
            'error': '',
        })
    except BaseException as exc:
        connection.send({
            'seconds': time.perf_counter() - started if 'started' in locals() else 0.0,
            'peak_rss_mb': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024.0,
            'status': 'error',
            'error': f'{type(exc).__name__}: {exc}'[:2000],
        })
    finally:
        connection.close()


def run_one(
    variant: str,
    model: str,
    train: object,
    labels: object,
    test: object,
    categorical: list[str],
) -> dict[str, object]:
    context = mp.get_context('fork')
    receive, send = context.Pipe(duplex=False)
    process = context.Process(
        target=child_fit,
        args=(send, model, train, labels, test, categorical),
    )
    started = time.perf_counter()
    process.start()
    send.close()
    peak_rss_mb = 0.0
    result: dict[str, object] | None = None
    while process.is_alive():
        observed = current_rss_mb(process.pid)
        if observed is not None:
            peak_rss_mb = max(peak_rss_mb, observed)
        if receive.poll(1.0):
            result = receive.recv()
            break
        if time.perf_counter() - started >= TIME_LIMIT_SECONDS:
            process.terminate()
            process.join(timeout=10.0)
            if process.is_alive():
                process.kill()
            process.join()
            result = {
                'seconds': time.perf_counter() - started,
                'peak_rss_mb': peak_rss_mb,
                'status': 'exceeded_3h',
                'error': '',
            }
            break
    process.join(timeout=10.0)
    if result is None and receive.poll():
        result = receive.recv()
    receive.close()
    if result is None:
        result = {
            'seconds': time.perf_counter() - started,
            'peak_rss_mb': peak_rss_mb,
            'status': 'error',
            'error': f'child_exit_code={process.exitcode}',
        }
    result['peak_rss_mb'] = max(float(result['peak_rss_mb']), peak_rss_mb)
    return {
        'variant': variant,
        'model': model,
        'n_train': len(train),
        'n_test': len(test),
        'p': len(train.columns),
        'n_categorical': len(categorical),
        'seconds': round(float(result['seconds']), 6),
        'peak_rss_mb': round(float(result['peak_rss_mb']), 3),
        'status': result['status'],
        'error': result['error'],
    }


def main() -> None:
    from phase1_driver.execution import WorkUnit, _pool_views
    from phase1_driver.runtime import set_offline_environment

    OUTPUT.mkdir(mode=0o700, parents=True, exist_ok=True)
    set_offline_environment()
    context = {'start': context_snapshot()}
    write_json(OUTPUT / 'timing_context.json', context)
    rows: list[dict[str, object]] = []
    write_timing(rows)
    unit = WorkUnit('M1', '44708', 'raw', 0, 'cpu', '214')
    _openml_id, train, labels, _train_index, test, _test_labels, _test_index, categorical = _pool_views(
        REGISTERED_ROOT, unit,
    )
    for model in MODELS:
        write_json(OUTPUT / 'timing_current.json', {
            'time_utc': timestamp(), 'variant': 'raw', 'model': model,
        })
        rows.append(run_one('raw', model, train, labels, test, categorical))
        write_timing(rows)
    context['raw_finished'] = context_snapshot()
    write_json(OUTPUT / 'timing_context.json', context)
    (OUTPUT / 'raw_finished.flag').touch()
    while not (OUTPUT / 'continue_m2.flag').is_file():
        time.sleep(5.0)
    slow_models = [
        row['model'] for row in rows
        if row['status'] == 'exceeded_3h' or float(row['seconds']) > 60.0
    ]
    if slow_models:
        unit = WorkUnit('M2', '44708', 'dispn_0.85_r0', 0, 'cpu', '214')
        _openml_id, train, labels, _train_index, test, _test_labels, _test_index, categorical = _pool_views(
            REGISTERED_ROOT, unit,
        )
        for model in slow_models:
            write_json(OUTPUT / 'timing_current.json', {
                'time_utc': timestamp(), 'variant': 'dispn_0.85_r0', 'model': model,
            })
            rows.append(run_one('dispn_0.85_r0', model, train, labels, test, categorical))
            write_timing(rows)
    context['end'] = context_snapshot()
    write_json(OUTPUT / 'timing_context.json', context)
    (OUTPUT / 'timing_done.flag').touch()


if __name__ == '__main__':
    main()
