"""Read-only Phase 1 timing extension for the 214 host.

This diagnostic imports the frozen driver in place, performs no checkpoint
writes, does not use held-out labels, and records only timing/resource/count
metadata plus prediction-shape/finite validation status.
"""

from __future__ import annotations

import argparse
import csv
import json
import multiprocessing as mp
import os
import resource
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


RUN_ROOT = Path("/root/autodl-tmp/phase1_run_b7ba9544")
REGISTERED_ROOT = Path("/root/autodl-tmp/tabular_prior_phase1_setup/tabular_prior_v2")
OUTPUT = Path("/root/phase1_diag_timeout")
SCHEDULER_PID_FILE = RUN_ROOT / "scheduler.pid"
TIME_LIMIT_SECONDS = 10800.0
MODELS = ("lr", "ebm", "catboost", "lgbm", "xgb", "rf")
FIELDS = (
    "openml_id",
    "fold",
    "variant",
    "model",
    "n_train",
    "n_test",
    "p",
    "n_categorical",
    "seconds",
    "peak_rss_mb",
    "status",
    "error",
    "actual_iterations",
    "actual_iterations_max",
    "iteration_limit_parameter",
    "iteration_limit_value",
)


def timestamp() -> str:
    return datetime.now(timezone.utc).isoformat()


def worker_count(scheduler_pid: int) -> int:
    output = subprocess.check_output(
        ["ps", "--ppid", str(scheduler_pid), "-o", "args="], text=True,
    )
    return sum("spawn_main" in line for line in output.splitlines())


def context_snapshot() -> dict[str, object]:
    scheduler_pid = int(SCHEDULER_PID_FILE.read_text().strip())
    return {
        "time_utc": timestamp(),
        "uptime": subprocess.check_output(["uptime"], text=True).strip(),
        "uptime_seconds": float(Path("/proc/uptime").read_text().split()[0]),
        "scheduler_pid": scheduler_pid,
        "scheduler_worker_count": worker_count(scheduler_pid),
    }


def write_json(path: Path, value: object) -> None:
    temporary = path.with_name(path.name + f".{os.getpid()}.tmp")
    with temporary.open("w", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, sort_keys=True, indent=2)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def write_timing(path: Path, rows: list[dict[str, object]]) -> None:
    temporary = path.with_name(path.name + f".{os.getpid()}.tmp")
    with temporary.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(rows)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def current_rss_mb(pid: int) -> float | None:
    try:
        content = Path(f"/proc/{pid}/status").read_text()
    except (FileNotFoundError, ProcessLookupError):
        return None
    for line in content.splitlines():
        if line.startswith("VmHWM:"):
            return float(line.split()[1]) / 1024.0
    return None


def capture_constructor(model: str) -> list[Any]:
    captured: list[Any] = []
    if model == "lr":
        import sklearn.linear_model as module
        name = "LogisticRegression"
    elif model == "ebm":
        import interpret.glassbox as module
        name = "ExplainableBoostingClassifier"
    elif model == "catboost":
        import catboost as module
        name = "CatBoostClassifier"
    elif model == "lgbm":
        import lightgbm as module
        name = "LGBMClassifier"
    elif model == "xgb":
        import xgboost as module
        name = "XGBClassifier"
    elif model == "rf":
        import sklearn.ensemble as module
        name = "RandomForestClassifier"
    else:
        raise ValueError(model)
    original = getattr(module, name)

    def factory(*args: Any, **kwargs: Any) -> Any:
        instance = original(*args, **kwargs)
        captured.append(instance)
        return instance

    setattr(module, name, factory)
    return captured


def iteration_metadata(model: str, estimator: Any) -> dict[str, object]:
    actual: object = ""
    actual_max: object = ""
    parameter = ""
    limit: object = ""
    if model == "lr" and hasattr(estimator, "n_iter_"):
        values = estimator.n_iter_.tolist()
        actual = json.dumps(values, separators=(",", ":"))
        actual_max = int(max(estimator.n_iter_.ravel()))
        parameter = "max_iter"
        limit = estimator.get_params().get("max_iter")
    elif model == "ebm" and hasattr(estimator, "best_iteration_"):
        values = estimator.best_iteration_.tolist()
        actual = json.dumps(values, separators=(",", ":"))
        actual_max = int(max(estimator.best_iteration_.ravel()))
        parameter = "max_rounds"
        limit = estimator.get_params().get("max_rounds")
    elif model == "catboost":
        count = int(estimator.get_tree_count())
        actual = count
        actual_max = count
        parameter = "iterations"
        limit = estimator.get_all_params().get("iterations")
    elif model == "xgb" and hasattr(estimator, "get_booster"):
        count = int(estimator.get_booster().num_boosted_rounds())
        actual = count
        actual_max = count
        parameter = "n_estimators"
        limit = estimator.get_params().get("n_estimators")
        if limit is None:
            limit = "None (library default)"
    elif model == "lgbm":
        if hasattr(estimator, "n_estimators_"):
            count = int(estimator.n_estimators_)
        else:
            count = int(estimator.booster_.current_iteration())
        actual = count
        actual_max = count
        parameter = "n_estimators"
        limit = estimator.get_params().get("n_estimators")
    elif model == "rf" and hasattr(estimator, "estimators_"):
        count = len(estimator.estimators_)
        actual = count
        actual_max = count
        parameter = "n_estimators"
        limit = estimator.get_params().get("n_estimators")
    return {
        "actual_iterations": actual,
        "actual_iterations_max": actual_max,
        "iteration_limit_parameter": parameter,
        "iteration_limit_value": limit,
    }


def child_fit(
    connection: Any,
    model: str,
    train: Any,
    labels: Any,
    test: Any,
    categorical: list[str],
) -> None:
    from phase1_driver.execution import cpu_fit_predict, seed_cpu_process
    from phase1_driver.runtime import offline_socket_guard, set_offline_environment
    import numpy as np

    started = time.perf_counter()
    try:
        seed_cpu_process()
        set_offline_environment()
        captured = capture_constructor(model)
        with offline_socket_guard():
            prediction, _detail = cpu_fit_predict(
                model, train, labels, test, categorical, REGISTERED_ROOT,
            )
        seconds = time.perf_counter() - started
        vector = np.asarray(prediction)
        if vector.shape != (len(test),):
            raise RuntimeError(
                f"prediction length {vector.shape}, expected {(len(test),)}"
            )
        if not np.isfinite(vector).all():
            raise RuntimeError("prediction contains non-finite values")
        metadata = iteration_metadata(model, captured[-1]) if captured else {
            "actual_iterations": "",
            "actual_iterations_max": "",
            "iteration_limit_parameter": "",
            "iteration_limit_value": "",
        }
        connection.send({
            "seconds": seconds,
            "peak_rss_mb": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024.0,
            "status": "ok",
            "error": "",
            **metadata,
        })
    except BaseException as exc:
        connection.send({
            "seconds": time.perf_counter() - started,
            "peak_rss_mb": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024.0,
            "status": "error",
            "error": f"{type(exc).__name__}: {exc}"[:2000],
            "actual_iterations": "",
            "actual_iterations_max": "",
            "iteration_limit_parameter": "",
            "iteration_limit_value": "",
        })
    finally:
        connection.close()


def run_one(
    openml_id: str,
    fold: int,
    variant: str,
    model: str,
    train: Any,
    labels: Any,
    test: Any,
    categorical: list[str],
) -> dict[str, object]:
    context = mp.get_context("fork")
    receive, send = context.Pipe(duplex=False)
    process = context.Process(
        target=child_fit,
        args=(send, model, train, labels, test, categorical),
    )
    started = time.perf_counter()
    process.start()
    send.close()
    peak_rss_mb = 0.0
    result: dict[str, object] | None = None
    while process.is_alive():
        observed = current_rss_mb(process.pid)
        if observed is not None:
            peak_rss_mb = max(peak_rss_mb, observed)
        if receive.poll(1.0):
            result = receive.recv()
            break
        if time.perf_counter() - started >= TIME_LIMIT_SECONDS:
            process.terminate()
            process.join(timeout=10.0)
            if process.is_alive():
                process.kill()
            process.join()
            result = {
                "seconds": time.perf_counter() - started,
                "peak_rss_mb": peak_rss_mb,
                "status": "exceeded_3h",
                "error": "",
                "actual_iterations": "",
                "actual_iterations_max": "",
                "iteration_limit_parameter": "",
                "iteration_limit_value": "",
            }
            break
    process.join(timeout=10.0)
    if result is None and receive.poll():
        result = receive.recv()
    receive.close()
    if result is None:
        result = {
            "seconds": time.perf_counter() - started,
            "peak_rss_mb": peak_rss_mb,
            "status": "error",
            "error": f"child_exit_code={process.exitcode}",
            "actual_iterations": "",
            "actual_iterations_max": "",
            "iteration_limit_parameter": "",
            "iteration_limit_value": "",
        }
    result["peak_rss_mb"] = max(float(result["peak_rss_mb"]), peak_rss_mb)
    return {
        "openml_id": openml_id,
        "fold": fold,
        "variant": variant,
        "model": model,
        "n_train": len(train),
        "n_test": len(test),
        "p": len(train.columns),
        "n_categorical": len(categorical),
        "seconds": round(float(result["seconds"]), 6),
        "peak_rss_mb": round(float(result["peak_rss_mb"]), 3),
        "status": result["status"],
        "error": result["error"],
        "actual_iterations": result["actual_iterations"],
        "actual_iterations_max": result["actual_iterations_max"],
        "iteration_limit_parameter": result["iteration_limit_parameter"],
        "iteration_limit_value": result["iteration_limit_value"],
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--job", choices=("44708_m2_ebm", "880_raw"), required=True)
    args = parser.parse_args()

    from phase1_driver.execution import WorkUnit, _pool_views
    from phase1_driver.runtime import set_offline_environment

    OUTPUT.mkdir(mode=0o700, parents=True, exist_ok=True)
    set_offline_environment()
    if args.job == "44708_m2_ebm":
        openml_id, fold, variant = "44708", 0, "dispn_0.85_r0"
        models = ("ebm",)
        output_path = OUTPUT / "timing_44708_m2_iterations.csv"
        context_path = OUTPUT / "timing_44708_m2_context.json"
        current_path = OUTPUT / "timing_44708_m2_current.json"
        done_path = OUTPUT / "timing_44708_m2_done.flag"
        unit = WorkUnit("M2", openml_id, variant, fold, "cpu", "214")
    else:
        openml_id, fold, variant = "880", 1, "raw"
        models = MODELS
        output_path = OUTPUT / "timing_880.csv"
        context_path = OUTPUT / "timing_880_context.json"
        current_path = OUTPUT / "timing_880_current.json"
        done_path = OUTPUT / "timing_880_done.flag"
        unit = WorkUnit("M1", openml_id, variant, fold, "cpu", "214")

    context: dict[str, object] = {
        "job": args.job,
        "start": context_snapshot(),
        "registered_root": str(REGISTERED_ROOT),
        "driver_import_root": str(Path.cwd()),
        "time_limit_seconds_per_model": TIME_LIMIT_SECONDS,
    }
    write_json(context_path, context)
    rows: list[dict[str, object]] = []
    write_timing(output_path, rows)
    (_openml_id, train, labels, _train_index, test, _test_labels,
     _test_index, categorical) = _pool_views(REGISTERED_ROOT, unit)
    del _test_labels
    for model in models:
        write_json(current_path, {
            "time_utc": timestamp(),
            "openml_id": openml_id,
            "fold": fold,
            "variant": variant,
            "model": model,
        })
        rows.append(run_one(
            openml_id, fold, variant, model,
            train, labels, test, categorical,
        ))
        write_timing(output_path, rows)
    context["end"] = context_snapshot()
    write_json(context_path, context)
    done_path.touch()


if __name__ == "__main__":
    main()
