# Phase 1 timeout diagnostic record

Output root: `/root/phase1_diag_timeout/`  
Diagnostic type: read-only and timing-only.  
Formal scheduler stop operations: 0.  
Formal scheduler restart operations: 0.  
Formal scheduler modifications: 0.  
Frozen repository or `phase1_driver` file modifications: 0.  
Performance quantities computed: 0.  
Uploads, pushes, and publications: 0.

## Execution times

- Initial 44708 raw timing start UTC: 2026-09-28T16:38:17.730918+00:00
- Initial 44708 raw timing end UTC: 2026-09-28T18:38:26.586420+00:00
- 44708 M2 EBM extension start UTC: 2026-09-29T01:05:48.172902+00:00
- 44708 M2 EBM extension end UTC: 2026-09-29T01:17:36.492764+00:00
- 880 six-model timing start UTC: 2026-09-29T01:05:47.753896+00:00
- 880 six-model timing end UTC: 2026-09-29T01:13:48.080803+00:00
- 880 CatBoost metadata retry start UTC: 2026-09-29T01:24:38.631108+00:00
- 880 CatBoost metadata retry end UTC: 2026-09-29T01:24:41.392030+00:00
- Report generated UTC: 2026-09-29T01:29:25.922194+00:00
- Scheduler worker count at each new timing start and end: 32.

## Commands and operations

- Read the live 214 scheduler command line and paths from `/proc/<scheduler-pid>/cmdline` and `schedule_cpu_214.sh`.
- Created or confirmed `/root/phase1_diag_timeout/continue_m2.flag`.
- Ran `diag_iteration_runner.py --job 44708_m2_ebm` in a detached process with `PYTHONHASHSEED=13`, `OMP_NUM_THREADS=1`, `MKL_NUM_THREADS=1`, `OPENBLAS_NUM_THREADS=1`, and offline environment variables.
- Ran `diag_iteration_runner.py --job 880_raw` concurrently in a second detached process with the same environment.
- Each model call used a separate child process with a 10800-second wall-clock limit.
- Each model call used frozen `_pool_views`, frozen `cpu_fit_predict`, `seed_cpu_process`, and `offline_socket_guard`.
- Held-out labels returned by `_pool_views` were discarded before model timing.
- Prediction checks were limited to vector length and finite values; prediction values were not written or printed.
- The first 880 CatBoost attempt completed fit and prediction, then the diagnostic metadata accessor raised `AttributeError: CatBoostClassifier object has no attribute get_tree_count`.
- Copied the first-pass diagnostic runner to `diag_iteration_runner_first_pass.py`.
- Changed only the diagnostic runner metadata accessor from `get_tree_count()` to `tree_count_`; no frozen file was changed.
- Ran `diag_iteration_runner.py --job 880_catboost_retry` in a new detached controller and child process.
- Copied the current `scheduler_failures.jsonl` and `fatal_attempts/` bytes from 686 and 214 into `hosts/`; both sources were absent on 4090.
- Generated `fatal_events_all.csv` from every copied JSONL row without deduplication.
- Read scheduler liveness and M1 checkpoint JSON counts without writing to any runtime-root or checkpoint-root.

## 44708 M2 timing row

| openml_id | fold | variant | model | n_train | n_test | p | n_categorical | seconds | peak_rss_mb | status | actual_iterations_max | iteration_limit_parameter | iteration_limit_value |
|---:|---:|---|---|---:|---:|---:|---:|---:|---:|---|---:|---|---:|
| 44708 | 0 | dispn_0.85_r0 | ebm | 1600 | 400 | 23 | 8 | 708.063468 | 446.953 | ok | 13826 | max_rounds | 50000 |

- EBM `best_iteration_` raw array is stored in `timing_44708_m2_iterations.csv`.

## 880 timing attempts

| attempt | model | n_train | n_test | p | n_categorical | seconds | peak_rss_mb | status | error | actual_iterations | actual_iterations_max | limit parameter | limit value |
|---:|---|---:|---:|---:|---:|---:|---:|---|---|---|---:|---|---|
| 1 | lr | 227 | 57 | 10 | 0 | 1.201653 | 178.391 | ok |  | [13] | 13 | max_iter | 2000 |
| 1 | ebm | 227 | 57 | 10 | 0 | 474.118247 | 204.492 | ok |  | [[2577,2581,2169,2615,2577,2575,2549,2581,2579,2579,2549,2577,2579,2578],[5251,5251,5251,5251,5251,5251,1500000,5251,5251,5251,5251,5251,5251,5251]] | 1500000 | max_rounds | 50000 |
| 1 | catboost | 227 | 57 | 10 | 0 | 2.609621 | 201.766 | error | AttributeError: 'CatBoostClassifier' object has no attribute 'get_tree_count' |  |  |  |  |
| 1 | lgbm | 227 | 57 | 10 | 0 | 0.669741 | 193.145 | ok |  | 100 | 100 | n_estimators | 100 |
| 1 | xgb | 227 | 57 | 10 | 0 | 0.586006 | 193.895 | ok |  | 100 | 100 | n_estimators | None (library default) |
| 1 | rf | 227 | 57 | 10 | 0 | 0.733843 | 188.219 | ok |  | 100 | 100 | n_estimators | 100 |
| 2 | catboost | 227 | 57 | 10 | 0 | 2.514444 | 202.055 | ok |  | 1000 | 1000 | iterations | 1000 |

- EBM `best_iteration_` raw array is stored in `timing_880.csv` and `timing_880_attempts.csv`.

## Cardinality screen

- Data rows: 478.
- CSV lines including header: 479.
- Sort order: `max_categorical_cardinality` descending.
- No labels were read for the cardinality counts.

## Fatal-event rows

- 686 JSONL rows copied: 25.
- 214 JSONL rows copied: 34.
- 4090 JSONL rows copied: 0; source file absent.
- `fatal_events_all.csv` data rows: 59.
- CSV columns: `task_key,attempt,timeout_seconds,error_type,reason,time`.
- Row deduplication: none.

## Status snapshot

- `status_snapshot.md` records scheduler PIDs, liveness, worker counts, M1 checkpoint JSON counts, failure-event counts, failed-unit task keys/reasons, and fatal-attempt file counts.

## SHA-256 of diagnostic files

The table covers every current file under `/root/phase1_diag_timeout/` except `diag_report.md` and the subsequently generated `SHA256SUMS.txt`.

| relative path | bytes | SHA-256 |
|---|---:|---|
| __pycache__/diag_iteration_runner.cpython-312.pyc | 17564 | 44cf46ab536aa69feb54918fdcfe01aad4ad8b9daeb2a8d790c4365f0d948080 |
| cardinality_screen.csv | 36388 | 67594dd96afde5364bfbcbd797f7274aa2f0d0316f5e3e11b29972738495ec04 |
| continue_m2.flag | 0 | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 |
| diag_iteration_runner.py | 13634 | 0c205b51640667f351217c5dfbcd7e8b0620db009620b18180e6cd3aac761514 |
| diag_iteration_runner_first_pass.py | 13126 | 756d35ff09f02f6ffde652ad01d1c196c793a8ab15d63eabc68c3c51a9119874 |
| fatal_events_all.csv | 5626 | eda8efc6b30b91f29ef80ae43fb17f3578d60996c1c61ba15f33b19eeaecc221 |
| hosts/214/fatal_attempts/M1__44708__raw__0__cpu.json | 365 | 1a7be60fd617be49b40d4f7f3f6c8b078ce9324dd4e807356659b1b07ed0c08e |
| hosts/214/fatal_attempts/M1__44708__raw__1__cpu.json | 365 | f1797ebf0fc6553163f1e2add799a8f7e6ccf65fa98717421148cb23678f7046 |
| hosts/214/fatal_attempts/M1__44708__raw__2__cpu.json | 364 | e7dc2cef7352c167a396c56534a063d6bad461fb3178ad79b19c734edde51193 |
| hosts/214/fatal_attempts/M1__44708__raw__3__cpu.json | 365 | d90b794e2c1505ea187fd21254c0c773d8a7d38196472b12f15e6cd985301026 |
| hosts/214/fatal_attempts/M1__44708__raw__4__cpu.json | 365 | 5d8149653cb50e473c10a35e2b45183b1c88644e780317a34fc94d506bf5e10c |
| hosts/214/fatal_attempts/M1__44710__raw__0__cpu.json | 365 | dae105e2668b6e2a35ab3cca045736f319e320aa3e1bde9a37cb765cc1f5b38c |
| hosts/214/fatal_attempts/M1__44710__raw__1__cpu.json | 364 | 80e2f1902bac56e1f93fe339ff3dcd6ea2492b26cd7092ae7e93769148f21288 |
| hosts/214/fatal_attempts/M1__44710__raw__2__cpu.json | 365 | bd99be73c0278c89abf95e789554218bc32a1c6ffaf85f7e12b51de221c8ead6 |
| hosts/214/fatal_attempts/M1__44710__raw__3__cpu.json | 365 | c989791add7a34395ece87e107f09201f3e799f22f73523bfde5429f08858b91 |
| hosts/214/fatal_attempts/M1__44710__raw__4__cpu.json | 365 | 4e84a200e778ad4bdb81e6ad6d99a208e9c2b79be903e69d91b368218dafe2f1 |
| hosts/214/fatal_attempts/M1__44712__raw__0__cpu.json | 364 | 4c216bfb6b16861a26d092a1aa5b0ae95f69f38ca56a21737745a31fd942839f |
| hosts/214/fatal_attempts/M1__44712__raw__1__cpu.json | 365 | ef7c83f84c5e2d5b3d14466ec51ab5254afb11a996754f6a98a66efc02d1271a |
| hosts/214/fatal_attempts/M1__44712__raw__2__cpu.json | 365 | ebb27984d5b67d6e92efa73fd54677f207bc4d57c9c36cc77140d0701f97a098 |
| hosts/214/fatal_attempts/M1__44712__raw__3__cpu.json | 362 | 0382152856e62a8f9b1a384d1ff934f0c1290b347bf7b4331feb25202abd92f0 |
| hosts/214/fatal_attempts/M1__44712__raw__4__cpu.json | 363 | 00f2231ea52ccb324f7a5127c021169ce1f3617f924a69f2eb49e69ed6600a6e |
| hosts/214/fatal_attempts/M1__880__raw__0__cpu.json | 182 | a823fb16970a98d67156605945b6bb1f144c35c870521a76f5d44ce0648935ff |
| hosts/214/fatal_attempts/M1__880__raw__1__cpu.json | 182 | 20353ceb40f303bc7e424a59c6ae3c76fa6248fa308c96dbcde602db77925ab2 |
| hosts/214/fatal_attempts/M1__880__raw__2__cpu.json | 182 | 3804bafe91d272918ee26993c236f1567589437d9ada5e24a97c07e63bfedb9d |
| hosts/214/fatal_attempts/M1__880__raw__3__cpu.json | 182 | d70246305bf2e77f92b6737283e2e046b09ed9a479905768caa63f6b58ccad81 |
| hosts/214/scheduler_failures.jsonl | 5220 | 155ef4da2d24e3be0781e1cefa026c8ddc1204c590ebcba52951619ce4629ae4 |
| hosts/214/status.json | 2075 | a1f125e0967265b9003d75db4f9bfa2c878df3d81d3629700fb995920155f606 |
| hosts/4090/status.json | 497 | 60a1c8d83e4d38cbb596c7f865fa8bcb9132bb03c0eae9ea05d72f80fd68540d |
| hosts/686/fatal_attempts/M1__44709__raw__0__cpu.json | 365 | 6f101ee6e6afd58fd464a4299f5aa757e5c76b4df8c89b120725fd191ff2a39f |
| hosts/686/fatal_attempts/M1__44709__raw__1__cpu.json | 364 | 3d0f0642b4790b7579b358a43daa8b2ca20dcac2758e13dc8c39d1820f4398e8 |
| hosts/686/fatal_attempts/M1__44709__raw__2__cpu.json | 363 | bbbca43787116570d7079cb335370792dd88e729b1db72f8ed2f818dc0c5ff7a |
| hosts/686/fatal_attempts/M1__44709__raw__3__cpu.json | 365 | fe8a2c97fa6e27bf62cecf0529a586e5c6a5eec204e6fad6d5e1cf6019aadec0 |
| hosts/686/fatal_attempts/M1__44709__raw__4__cpu.json | 363 | a5c59b6d8ddf2b7e5e851d14cf673dff1b898b67449b69ee24c05605ebcacb8d |
| hosts/686/fatal_attempts/M1__44711__raw__0__cpu.json | 364 | 1ab5639034c36a9827709a23a581540a4736e42f6c48c7fbf4c3d5a1258ac76f |
| hosts/686/fatal_attempts/M1__44711__raw__1__cpu.json | 365 | d68e1272cb69c1493b61d0be4eab71c6ed35493293cb583c6b6da5ab9876bdb2 |
| hosts/686/fatal_attempts/M1__44711__raw__2__cpu.json | 363 | e58ced7362ce2627f514f2e7eca532ac13aa05c3932250f0b99ea7a5abea7c2b |
| hosts/686/fatal_attempts/M1__44711__raw__3__cpu.json | 364 | e7f628cbc49af80dafcd26a7cdb4b2e61a27abef0e0486253f349fcc7e0b95b9 |
| hosts/686/fatal_attempts/M1__44711__raw__4__cpu.json | 365 | 4333365d85238a35eb6b281e3695df8f369111c0fe3cb2a8fe9d24df86670968 |
| hosts/686/fatal_attempts/M1__818__raw__0__cpu.json | 182 | 95b3c539aa5e522226e928c95779e3083e0ffa43da9b8558d635bb9619d627dd |
| hosts/686/fatal_attempts/M1__818__raw__1__cpu.json | 182 | a6fff72aba71de17d888260f8df56aaa5384b9dce04fd9f14887981808d82dd1 |
| hosts/686/fatal_attempts/M1__818__raw__2__cpu.json | 182 | f91c2d7167982024b6e43996bb0e028c024634fa9a4e4171513c206c5b4e615a |
| hosts/686/fatal_attempts/M1__818__raw__3__cpu.json | 181 | ac9e8b58087556671e829b5fe03d3b4c3294beba5e2608a92d7142664642a574 |
| hosts/686/fatal_attempts/M1__818__raw__4__cpu.json | 182 | 2175e4ff5b15dcd15f79b7b279794e8548cd018d131f35f2f4022753232da335 |
| hosts/686/scheduler_failures.jsonl | 3830 | 7547cb1b824d579dbe8184435eeebd9556ad75666435accf85f1f52acb31dfcf |
| hosts/686/status.json | 497 | c1e607f9ce24d6c77dc4f732c36bbaf850a36210a6c40ebbd353ce9bc546c1df |
| raw_finished.flag | 0 | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 |
| status_snapshot.md | 2377 | 76405f6f383bd3be3b69dea6fedd07beeb18343e0a47fc4debc8664513897691 |
| timing_44708.csv | 402 | 9334a2150d0e3fde169e8d4473c96860c6dffd130ca377f17111f25c62de2308 |
| timing_44708_m2_context.json | 737 | 7cd9b0ac62773ffd215acc115cf44d3d7f77d2b36c86df83cfc01dcab097f4a0 |
| timing_44708_m2_current.json | 138 | 9f2832d596073bf3dc84129ed9ab084cba860c6c7fe7603aa3b7fd9b488b1849 |
| timing_44708_m2_done.flag | 0 | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 |
| timing_44708_m2_iterations.csv | 431 | 53d9f392a23f0b1bb4ba08799e99cfe57f06be3265cb7a80311a4886d13c7807 |
| timing_44708_m2_runner.log | 0 | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 |
| timing_880.csv | 852 | 966e241a4cfd0099da86e2f521900580ddf75748547ef757921ad43e5ac1ed0b |
| timing_880_attempts.csv | 953 | 4848e58946f8a3899af3c9819d38736e79b1407b1c1c6d7b5f69805289e892d7 |
| timing_880_catboost_retry.csv | 261 | a7992daadee1b2b5084a7540063707ffa6eb3ab6216411976fc6354ce211a98e |
| timing_880_catboost_retry_context.json | 744 | db13aee7a2e20ec9102cc06c934669eb03bc3447ed57d8116540028716b17669 |
| timing_880_catboost_retry_current.json | 131 | a731daed86d036e5d92b6af2a51f89f6cb56a6481f4c88a838713be262bd53c5 |
| timing_880_catboost_retry_done.flag | 0 | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 |
| timing_880_catboost_retry_runner.log | 0 | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 |
| timing_880_context.json | 733 | 16443e1e6d66a89cbc92ac19bdb122a89bee457a2586fd1884712703d1810728 |
| timing_880_current.json | 125 | eb4766fbd2d50f0fba0fb5245a77dda510fb235653b61319bd74a4cdc2527508 |
| timing_880_done.flag | 0 | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 |
| timing_880_runner.log | 0 | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 |
| timing_context.json | 778 | 2e1673cd3cbb9c6231b1017345d60edabb6772475c972d3cfa6a6dec1574a13b |
| timing_current.json | 101 | cc6c757086f2fbd2aa783934451028db544b144423b9b5bcf7b85c18438ff16e |
| timing_done.flag | 0 | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 |
| timing_runner.log | 0 | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 |
| timing_runner.py | 8155 | a4c1e8dded9f1b0ed7bc0743de027218673400ed79a3e8d82da13c111d1cdb0b |
